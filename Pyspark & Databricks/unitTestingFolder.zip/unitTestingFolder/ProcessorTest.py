# Databricks notebook source
# MAGIC %run /Users/sadhu.dhanunjay@diggibyte.com/unitTestingFolder/commonFunctionTest

# COMMAND ----------

import unittest
class test_(unittest.TestCase):
    def test_duplicate_primary_key(self):
        path="dbfs:/FileStore/tbro"
        format_name="csv"
        options={"Header":True,"InferSchema":True}
        df=create_df(path,format_name,**options)
        primary_key_columns = ['name']
        duplicate_count = df.groupBy(primary_key_columns).count().filter("count > 1").count()
        self.assertEqual(duplicate_count, 0)

    # def test_non_null_primary_key(self):
    #     path="dbfs:/FileStore/tbro"
    #     format_name="csv"
    #     options={"Header":True,"InferSchema":True}
    #     df=create_df(path,format_name,**options)
    #     primary_key_columns = ['name']
    #     null_count = df.where(df[primary_key_columns].isnall()).count()
    #     # null_counts = [df.where(df[col].isNull()).count() for col in primary_key_columns]

    #     self.assertEqual(null_count, 0)

s = unittest.TestLoader().loadTestsFromTestCase(test_)
unittest.TextTestRunner(verbosity=2).run(s)

# COMMAND ----------

path="dbfs:/FileStore/tbro"
format_name="csv"
options={"Header":True,"InferSchema":True}
df=create_df(path,format_name,**options)
display(df)

# COMMAND ----------

