# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

schema = StructType([
    StructField("web_pages", ArrayType(StringType()), True),
    StructField("name", StringType(), True),
    StructField("domains", ArrayType(StringType()), True),
    StructField("country", StringType(), True),
    StructField("state-province", StringType(), True),
    StructField("alpha_two_code", StringType(), True)])

# COMMAND ----------

