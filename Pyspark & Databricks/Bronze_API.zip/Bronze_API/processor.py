# Databricks notebook source
# MAGIC %run /Users/sadhu.dhanunjay@diggibyte.com/Interview/API_json_file/Bronze_API/common_functions

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Empty DataFrame

# COMMAND ----------

df=create_empty_dataframe()

# COMMAND ----------

lst = ['Jordan','united states','United Kingdom','Turkey','Egypt']
for x in lst:
    df=Reading_Creatint_API(f'http://universities.hipolabs.com/search?country={x}',df)

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %md 
# MAGIC ### Writing to Delta Table
# MAGIC

# COMMAND ----------

create_delta_table(df,format_name="delta",mode="overwrite",name="api_delta_table")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from api_delta_table

# COMMAND ----------

