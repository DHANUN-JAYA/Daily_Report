# Databricks notebook source
# MAGIC %md
# MAGIC ### importing schema notebook

# COMMAND ----------

# MAGIC %run /Users/sadhu.dhanunjay@diggibyte.com/Interview/API_json_file/Bronze_API/Schema

# COMMAND ----------

# MAGIC %md
# MAGIC ### Import Functions

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import requests

# COMMAND ----------

# MAGIC %md
# MAGIC ### Creating Empty Data Frame

# COMMAND ----------

def create_empty_dataframe():
    return spark.createDataFrame([], schema)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reading API

# COMMAND ----------

def Reading_Creatint_API(path,df_target):
    response = requests.get(path)
    df_temp=spark.createDataFrame(response.json(),schema)
    return df_target.union(df_temp)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Writing to Delta Table

# COMMAND ----------

def create_delta_table(df,format_name,mode,name):
    df.write.format(format_name).mode(mode).saveAsTable(name)

# COMMAND ----------

